package systemApiStructs

type MonitorGetDiskStateByPathReq struct {
	Path string `json:"path"`
}
