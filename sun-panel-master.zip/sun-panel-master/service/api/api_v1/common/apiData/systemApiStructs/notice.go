package systemApiStructs

type NoticeGetListByDisplayTypeReq struct {
	DisplayType []int `json:"displayType"`
}
