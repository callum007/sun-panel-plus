declare namespace Notice{

    interface NoticeInfo extends Common.InfoBase{
        title:string 
        content:string
        displayType:number
        oneRead:number
        url:string
        isLogin:number
    }


}