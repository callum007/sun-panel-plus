export enum VisitMode {
  'VISIT_MODE_LOGIN' = 0, // 登录状态
  'VISIT_MODE_PUBLIC' = 1, // 公开状态
}
